<?php

$hostname = "localhost"; // Host

$username = "id17661151_nina_rosine_"; // Username

$password = "$#XlO$0*[kk!e9nP"; // Password

$database = "id17661151_112162_rosine"; // Database

?>