<?php
class DB_Connect { // Connection Class

    private $conn; // Connection Attribute
    
    public function connect() { // Connection Function

        require_once "DB_Config.php"; // Database Configuration file

        $this->conn = new mysqli(
            $hostname, 
            $username, 
            $password, 
            $database
        ); // Connect using the params from the config file

        return $this->conn;
    }
}
?>