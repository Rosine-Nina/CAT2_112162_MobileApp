<?php

require_once '../include/DB_Functions.php'; // Functions file

$db = new DB_Functions(); // New functions object

$response = array("error" => FALSE); // JSON Response Array

$inputFname = isset($_POST['fname']);
$inputLname = isset($_POST['lname']);
$inputEmail = isset($_POST['email']);
$inputPassword = isset($_POST['password']);
$inputConfirmPassword = isset($_POST['confirm_password']); 
 
if (
    $inputFname && 
    $inputLname && 
    $inputEmail && 
    $inputPassword && 
    $inputConfirmPassword) { // Checks if Registration Form was sent using POST

    // Receive the POST parameters

    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if (
        $fname == NULL ||
        $lname == NULL ||
        $email == NULL ||
        $password == NULL ||
        $confirm_password == NULL
    ) {

        $response["error"] = TRUE;
        
        $response["error_message"] = "One of your input fields is empty";

        echo json_encode($response);

    } else if ($password != $confirm_password) {

        $response["error"] = TRUE;

        $response["error_message"] = "Your passwords do not match!";

        echo json_encode($response);

    } else if (strlen($password) < 8) {

        $response["error"] = TRUE;

        $response["error_message"] = "Your password must be at least 8 characters in length";

        echo json_encode($response);

    } else {
        $check_user = $db->checkUser($email);

        if ($check_user) { // If User is already registered

            $response["error"] = true;

            $response["error_message"] = "User already exists with" . $email;

            echo json_encode($response);
        } else { // If User does not exist

            $user = $db->createAccount(
                $fname,
                $lname,
                $email,
                $password,
                $confirm_password
            ); // Creates new user

            if ($user) { // Account created successfully

                $response["error"] = false;

                $response["user"]["uuid"] = $user["uuid"];

                $response["user"]["fname"] = $user["fname"];

                $response["user"]["lname"] = $user["lname"];

                $response["user"]["email"] = $user["email"];

                $response["user"]["password"] = $user["hashed_password"];

                $response["user"]["created_at"] = $user["created_at"];

                echo json_encode($response);
            } else { // Account not created

                $response["error"] = true;

                $response["error_message"] = "Unknown error occurred while creating account";

                echo json_encode($response);
            }
        }
    }
    
} else {

    $response["error"] = TRUE;

    $response["error_message"] = "Required parameters (fname, lname, email or password) is missing!";

    echo json_encode($response);
}


?>