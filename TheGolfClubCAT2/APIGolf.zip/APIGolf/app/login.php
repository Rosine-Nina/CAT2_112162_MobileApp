<?php

require_once '../include/DB_Functions.php'; // Functions file

$db = new DB_Functions(); // Creating a new Functions object

$response = array("error" => FALSE);

$inputEmail = isset($_POST['email']);

$inputPassword = isset($_POST['password']);

if ($inputEmail && $inputPassword) { // Checks if the Login Form was sent using POST

    // Receive POST params

    $email = $_POST['email']; // Email

    $password = $_POST['password']; // Password

    $user = $db->authUser($email, $password); // Authenticate User

    if ($user) { // User is found
    
        $response["error"] = FALSE;

        $response["user"]["uuid"] = $user["uuid"]; // Unique User ID

        $response["user"]["fname"] = $user["fname"]; // Firstname
        
        $response["user"]["lname"] = $user["lname"]; // Username

        $response["user"]["email"] = $user["email"]; // Email

        $response["user"]["created_at"] = $user["created_at"]; // Created at

        echo json_encode($response);
        
        
    } else {
        
        $response["error"] = TRUE;
        
        $response["error_message"] = "Login Failed. Please check your user credentials";
        
        echo json_encode($response);
        
    }
} else {

    $response["error"] = TRUE;

    $response["error_msg"] = "Required parameters email or password is missing!";

    echo json_encode($response);
}

?>